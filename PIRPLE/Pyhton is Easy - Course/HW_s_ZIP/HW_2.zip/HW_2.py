# -*- coding: utf-8 -*-
"""
Created on Wed Nov 18 20:56:30 2020

@author: Gabriel Melendez
"""

#%%

'''

Hw_2_Pirple

Functions 

Gabriel Meléndez
'''

def composer():
    print('Freddie Mercury')
    
def theme():
    print('Loneliness')
    
def texture():
    print('homophony')
    

composer()
texture()
theme()