# -*- coding: utf-8 -*-
"""
Created on Wed Nov 18 15:02:15 2020

@author: Gabriel Melendez
"""


#%%
'''
HW_1_Pirple by Gabriel M

Song Descrpition

Bohemian Rhapsody by Queen
'''

Artist = 'Queen'
Genre = 'Classic Rock or Rock'
Duration_Seconds = 354
Composer = 'Freddie Mercury'
Form = 'Song, Opera, Rock'
Theme = 'Loneliness'
Texture = 'homophony'

#this will display the description of Bohemian Rhapsody
print('Artist: ', Artist)
print('Genre: ', Genre)
print('Duration_Seconds: ', Duration_Seconds)
print('Composer: ', Composer)
print('Form: ', Form)
print('Theme: ', Theme)
print('Texture: ', Texture)
